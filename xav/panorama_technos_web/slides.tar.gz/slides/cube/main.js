var main=function() {
    var isContexte=Contexte.instance({canvas_id: "mon_canvas"});
};