<?
include("libs/libs.php");

include("classes/webgl/Contexte.js");
include("classes/webgl/Maillage.js");
include("classes/webgl/Objet.js");
include("classes/webgl/Vue.js");
include("classes/webgl/Scene.js");
include("classes/webgl/shaders.php");
include("classes/webgl/VBO.js");
include("classes/webgl/VBO_indices.js");
include("classes/webgl/Cube.js");

include("main.js");
?>
