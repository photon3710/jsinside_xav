<!DOCTYPE html>
<html>
    <head>
        <title>Cube tournant coloré</title>
        <script type="text/javascript" src="script.php"></script>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <link rel="stylesheet" type="text/css" href="style/style.css"/>
    </head>
    <body onload="main()">
        <canvas id="mon_canvas" width="800" height="600"></canvas>
    </body>
</html>
